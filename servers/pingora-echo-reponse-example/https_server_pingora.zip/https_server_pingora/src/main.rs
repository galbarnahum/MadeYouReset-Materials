#[global_allocator]
static GLOBAL: jemallocator::Jemalloc = jemallocator::Jemalloc;

use pingora::listeners::tls::TlsSettings;
use pingora::protocols::TcpKeepalive;
use pingora::server::configuration::Opt;
use pingora::server::{Server, ShutdownWatch};
use pingora::services::background::{background_service, BackgroundService};
use pingora::services::{listening::Service as ListeningService, Service};

use async_trait::async_trait;
use clap::Parser;
use tokio::time::interval;

use std::time::Duration;

mod app;
mod service;

pub struct ExampleBackgroundService;
#[async_trait]
impl BackgroundService for ExampleBackgroundService {
    async fn start(&self, mut shutdown: ShutdownWatch) {
        let mut period = interval(Duration::from_secs(1));
        loop {
            tokio::select! {
                _ = shutdown.changed() => {
                    break;
                }
                _ = period.tick() => {}
            }
        }
    }
}

const USAGE: &str = r#"
Usage
port 6142: TCP echo server
nc 127.0.0.1 6142

port 6143: TLS echo server
openssl s_client -connect 127.0.0.1:6143

port 6145: Http echo server
curl http://127.0.0.1:6145 -v -d 'hello'

port 6148: Https echo server
curl https://127.0.0.1:6148 -vk -d 'hello'

port 6141: TCP proxy
curl http://127.0.0.1:6141 -v -H 'host: 1.1.1.1'

port 6144: TLS proxy
curl https://127.0.0.1:6144 -vk -H 'host: one.one.one.one' -o /dev/null

port 6150: metrics endpoint
curl http://127.0.0.1:6150
"#;

pub fn main() {
    env_logger::init();

    print!("{USAGE}");

    let opt = Some(Opt::parse());
    let mut my_server = Server::new(opt).unwrap();
    my_server.bootstrap();

    let cert_path = "/home/certs/server.crt".to_string();
    let key_path = "/home/certs/server.key".to_string();

    let mut echo_service = service::echo::echo_service();
    echo_service.add_tcp("0.0.0.0:180");
    echo_service
        .add_tls("0.0.0.0:6143", &cert_path, &key_path)
        .unwrap();

    let mut echo_service_http = service::echo::echo_service_http();

    let mut options = pingora::listeners::TcpSocketOptions::default();
    options.tcp_fastopen = Some(10);
    options.tcp_keepalive = Some(TcpKeepalive {
        idle: Duration::from_secs(60),
        interval: Duration::from_secs(5),
        count: 5,
        #[cfg(target_os = "linux")]
        user_timeout: Duration::from_secs(85),
    });

    echo_service_http.add_tcp_with_settings("0.0.0.0:6145", options);
    echo_service_http.add_uds("/tmp/echo.sock", None);

    let mut tls_settings = TlsSettings::intermediate(&cert_path, &key_path).unwrap();
    tls_settings.enable_h2();
    echo_service_http.add_tls_with_settings("0.0.0.0:443", None, tls_settings);

    let proxy_service = service::proxy::proxy_service(
        "0.0.0.0:80",
        "192.168.205.131:8000",
    );

    let proxy_service_ssl = service::proxy::proxy_service_tls(
        "0.0.0.0:6144",
        "1.1.1.1:443",
        "one.one.one.one",
        &cert_path,
        &key_path,
    );

    let mut prometheus_service_http = ListeningService::prometheus_http_service();
    prometheus_service_http.add_tcp("127.0.0.1:6150");

    let background_service = background_service("example", ExampleBackgroundService {});

    let services: Vec<Box<dyn Service>> = vec![
        Box::new(echo_service),
        Box::new(echo_service_http),
        Box::new(proxy_service),
        Box::new(proxy_service_ssl),
        Box::new(prometheus_service_http),
        Box::new(background_service),
    ];
    my_server.add_services(services);
    my_server.run_forever();
} 