use crate::app::echo::{EchoApp, HttpEchoApp};
use pingora::services::listening::Service;

pub fn echo_service() -> Service<EchoApp> {
    Service::new("Echo Service".to_string(), EchoApp)
}

pub fn echo_service_http() -> Service<HttpEchoApp> {
    Service::new("Echo Service HTTP".to_string(), HttpEchoApp)
} 